//variaveis da bolinha
let xBolinha = 300;
let yBolinha = 200;
let diametro = 22;
let raio = diametro / 2;

//velocidade da bolinha
let velocidadexBolinha = 6;
let velocidadeyBolinha = 6;

//variaveis da raquete
let xRaquete = 8;
let yRaquete = 170;
let RaqueteComprimento = 12;
let RaqueteAltura = 80;

//variaveis do oponente
let xRaqueteOponente = 580;
let yRaqueteOponente = 170;
let velocidadeYOponente;

let colidiu = false;

//placar do jogo
let MeusPontos = 0;
let pontosDoOponente = 0;

//sons do jogo
let raquetada;
let ponto;
let trilha;

function preload(){
trilha = loadSound("trilha.mp3");
ponto = loadSound ("ponto.mp3");
raquetada = loadSound("raquetada.mp3");
}

function setup() {
createCanvas(600, 400);
trilha.loop();
}

function draw() {
background(0);
mostraBolinha();
movimentaBolinha();
verificaColisaoBorda();
mostraRaquete(xRaquete, yRaquete);
movimentaMinhaRaquete();
//VerificaColisaoRaquete();
VerififcaColisaoRaquete(xRaquete, yRaquete);
mostraRaquete(xRaqueteOponente, yRaqueteOponente);
movimentaRaqueteOponente();
VerififcaColisaoRaquete(xRaqueteOponente, yRaqueteOponente);
incluiPlacar();
marcaPonto();
}

function mostraBolinha(){
circle(xBolinha, yBolinha, diametro);
}
function movimentaBolinha (){
xBolinha += velocidadexBolinha;
yBolinha += velocidadeyBolinha;
  }

function verificaColisaoBorda (){
if (xBolinha + raio> width ||
xBolinha - raio< 0){
velocidadexBolinha *= -1;
  }
if (yBolinha + raio> height ||
yBolinha - raio< 0){
velocidadeyBolinha *= -1;
 }
}

function mostraRaquete (x,y){
rect(x, y, RaqueteComprimento, RaqueteAltura);
  }

function movimentaMinhaRaquete(){
if (keyIsDown(UP_ARROW)){
yRaquete -= 10;
  }
if (keyIsDown(DOWN_ARROW)){
yRaquete += 10;
  }
}

function VerificaColisaoRaquete(){
if (xBolinha -raio < xRaquete + RaqueteComprimento
&& yBolinha - raio < yRaquete + RaqueteAltura && 
yBolinha + raio > yRaquete){
velocidadexBolinha *= -1;
raquetada.play();
  } 
}

function VerififcaColisaoRaquete(x,y){
colidiu =
collideRectCircle(x,y,RaqueteComprimento,RaqueteAltura,xBolinha,yBolinha,raio);
if (colidiu){
velocidadexBolinha *= -1;
raquetada.play();
    }
} 


function movimentaRaqueteOponente(){
if (keyIsDown(87)){
yRaqueteOponente -= 10;
  }
if (keyIsDown(83)){
yRaqueteOponente += 10;
 }
} 

function incluiPlacar(){
stroke(255);
textAlign(CENTER);
textSize(20);
fill(color (255,0,255));
rect(150, 10, 40, 20);
fill(255);
text(MeusPontos, 170, 26);
fill(color (255,0,255));
rect(450, 10, 40, 20);
fill(255);
text(pontosDoOponente, 470, 26);
} 

function marcaPonto(){
if(xBolinha > 590){
MeusPontos += 1;
ponto.play();
  }
if(xBolinha < 10){
pontosDoOponente += 1;
ponto.play();
  }
}